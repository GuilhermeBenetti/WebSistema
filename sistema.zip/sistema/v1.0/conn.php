<?php

    $servidor = "localhost:3306";
    $usuario = "fmanhaes_guilherme_megapontocom";
    $senha = "Meg@com2021";
    $dbname = "fmanhaes_clientes_primeiraconsulta";

$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>